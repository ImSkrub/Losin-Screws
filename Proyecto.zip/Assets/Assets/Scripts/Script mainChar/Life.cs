using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using UnityEngine.UI;

public class Life : MonoBehaviour, IDamageable
{
    //Variables interfaz IDamageable//
    public float CurrentHealth => currentHealth;

    public float maxHealth = 100; //Maximo de vida
    public float damageCooldown = 1f; //Da�o
    public float currentHealth; //Vida que llevas en el juego
    private SpriteRenderer spriteRenderer; //Renderizado barra
    private float currentTime;
    public event Action OnDeath; //Muerte del jugador como evento.

    //Color al recibir da�o.
    public Color damageColor = Color.red;
    private Color originalColor;

    //Stat de vida en Canvas
    public Image lifebar;

    private void Start()
    {
        currentHealth = maxHealth;
        spriteRenderer = GetComponent<SpriteRenderer>();
        originalColor = spriteRenderer.color;
    }

    private void Update()
    {
        lifebar.fillAmount = currentHealth / maxHealth;

        currentTime += Time.deltaTime;
        //Da�o
        if (currentHealth <= 0)
        {
            Die();
        }
    }

    //Recibie da�o
    public void GetDamage(int value)
    {
        currentHealth -= value; //currentHealth = currentHealth - value; 
        spriteRenderer.color = damageColor;
        Invoke("RestoreColor", 0.5f);
    }

    private void RestoreColor()
    {
        // Restaurar el color original del sprite
        spriteRenderer.color = originalColor;
    }

    //Muere.
    public void Die()
    {
        //anim.SetTrigger("Death");
        Destroy(gameObject, 1f);
        OnDeath?.Invoke();
    }
}
