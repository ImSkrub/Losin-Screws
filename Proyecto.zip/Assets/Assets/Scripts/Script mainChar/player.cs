using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class player : MonoBehaviour
{
    //Variables importantes//
    private Rigidbody2D Rigidbody2D;
    Animator anim;

    //Movimiento
    public float Speed;
    private float Horizontal;
    private bool isFacingRight = true;

    //Salto
    public float CheckGround;
    public float jumpForce = 10f;
    public bool isJumping = false;
    private float currentTime; 

    //Start del juego.
    void Start()
    {
        Rigidbody2D = GetComponent<Rigidbody2D>();
        anim = GetComponent<Animator>();
    }

    //Update del juego.
    void Update()
    {
        ///////Movimiento y teclas//////.
        Horizontal = Input.GetAxisRaw("Horizontal");

        if (Horizontal != 0)
            anim.SetBool("Walk", true);
        else
            anim.SetBool("Walk", false);

        //Saltar
        if (Input.GetKeyDown(KeyCode.W) && !isJumping)
        {
            Rigidbody2D.AddForce(Vector2.up * jumpForce, ForceMode2D.Impulse);
            isJumping = true;
            anim.SetBool("Jump", true);
        }

        //Giro.
        if (Horizontal > 0) transform.eulerAngles = Vector3.zero;
        else if (Horizontal < 0) transform.eulerAngles = new Vector3(0, 180, 0);

        currentTime += Time.deltaTime;
    }

    public void AplicarPowerUp(float increasedJumpForce, float increasedSpeed)
    {
        jumpForce += increasedJumpForce;
        Speed += increasedSpeed;
    }

    private void Jump()
    {
        Rigidbody2D.AddForce(Vector2.up * jumpForce);
    }
    
    //trampolin
    public void ForcedJump()
    {
       
      Rigidbody2D.AddForce(Vector2.up * 600);
    }

    // FixedUpdate del juego
    private void FixedUpdate()
    {
        Rigidbody2D.velocity = new Vector2(Horizontal * Speed, Rigidbody2D.velocity.y);
    }

    //Colision piso y daño.
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.layer == 8)
        {
            anim.SetBool("Jump", false);
            isJumping = false;
        }
    }

    //Moneda agarra.
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.layer == 10)
        {
            GameManager.Instance.coin = GameManager.Instance.coin+1;
        }
        if (collision.gameObject.layer == 11)
        {
            GameManager.Instance.powerUp = GameManager.Instance.powerUp + 1;
        }
    }
}
