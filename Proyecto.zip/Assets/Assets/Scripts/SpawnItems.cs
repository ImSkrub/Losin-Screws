using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnItems : MonoBehaviour
{
    public GameObject ItemPrefab1;
    public GameObject ItemPrefab2;
    public GameObject ItemPrefab3;
    public GameObject ItemPrefab4;

    public Transform spawnPoint;

    int i;
    // Start is called before the first frame update
    void Start()
    {
        i = UnityEngine.Random.Range(1, 5);
        GenerarSpawner(i);
    }
    private void GenerarSpawner(int r)
    {
        switch (r)
        {
            case 1:
                Instantiate(ItemPrefab1, spawnPoint.position, spawnPoint.rotation);
                break;
            case 2:
                Instantiate(ItemPrefab2, spawnPoint.position, spawnPoint.rotation);
                break;
            case 3:
                Instantiate(ItemPrefab3, spawnPoint.position, spawnPoint.rotation);
                break;
            case 4:
                Instantiate(ItemPrefab4, spawnPoint.position, spawnPoint.rotation);
                break;
            default:
                break;
        }
    }
}
