using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Tesla : MonoBehaviour
{
    ///Variables///
    [SerializeField] GameObject follow; //Seguir al player como objeto
    public Transform player; //Ubiacion del jugador.
    [SerializeField] float distToAttack; //Distancia dispara el rayo.
    [SerializeField] float attackVel; //Velocidad disparo del rayo.
    [SerializeField] float closestDist; //Distancia que tan cerca llega a disparar.
    [SerializeField] float lerpSpeedRotation;
    Rigidbody2D rb;
    Vector3 enemyDirection;
    Animator anim;
    public GameObject weaponPrefab; //Rayo 1
    public Transform weaponSlot; //Posicion que dispara.
    public float attackDelay = 10f; //Tiempo que tarda en disparar.
    private float currentTime;

    private void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        anim = GetComponent<Animator>();
    }

    private void Update()
    {

        //Movimiento y ataque de la tesla.
        currentTime += Time.deltaTime;
        enemyDirection = follow.transform.position - transform.position;
        if (enemyDirection.magnitude < distToAttack && enemyDirection.magnitude > closestDist)
        {
            if (currentTime >= attackDelay)
            {
                Instantiate(weaponPrefab, weaponSlot.position, transform.rotation);
                transform.right = Vector3.Lerp(transform.right, enemyDirection, lerpSpeedRotation * Time.deltaTime);
                currentTime = 0;
            }
        }
    }

    //Radio para detectar jugador mediante GizMos.
    private void OnDrawGizmos()
    {
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(transform.position, distToAttack);
    }
}
