using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class canon : MonoBehaviour
{
    public GameObject bola;
   
    private float currentTime;

    public Transform spawnpoint; //Donde se genera la bola
    public float fireRate = 1f; //Cada cuanto se disparan

    // Start is called before the first frame update
    private void Start()
    {
    }

    // Update is called once per frame
    void Update()
    {
        currentTime += Time.deltaTime;

        if (currentTime > fireRate)
        {
            AudioManager.instance.PlaySound(1);
            GameObject ball = Instantiate(bola, spawnpoint.position, transform.rotation);
            currentTime = 0;
        }

    }
}
