using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BolaDeCanon : MonoBehaviour
{
    Animator anim;
    public float speed = 5f;
    public float lifeTime = 5f;
    private float currentTime;
    public int damage;

    void Update()
    {
        transform.Translate(speed * Time.deltaTime, 0, 0);
        currentTime += Time.deltaTime;

        if (currentTime >= lifeTime)
        {
            Destroy(gameObject);
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        Life _Life = collision.collider.GetComponent<Life>();
        if (_Life != null)
        {
            _Life.GetDamage(damage);
            Destroy(gameObject);
        }

        //choque acido
        if (collision.gameObject.layer == 4)
        {
            Destroy(gameObject);
        }
    }
}