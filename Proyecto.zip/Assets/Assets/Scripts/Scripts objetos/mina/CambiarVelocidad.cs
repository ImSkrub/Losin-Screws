using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CambiarVelocidad: MonoBehaviour
{
    public Animator animator; // Asigna el componente Animator en el Inspector.

    void Start()
    {
        animator.speed = 0.3f; // Cambia la velocidad de la animaci�n a 2x.
    }
}

