using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Explosion : MonoBehaviour
{
    [SerializeField] private float fuerzaExplosion = 30f;
    [SerializeField] private float radioExplosion = 5f; 

    private Animator animator; 
    private Rigidbody2D Rigidbody2D;

    public int damage = 5;

    void Start()
    {
        Rigidbody2D = GetComponent<Rigidbody2D>();
        animator = GetComponent<Animator>();
        animator.speed = 0.3f; 
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Player"))
        {
            Life _Life = collision.GetComponent<Life>();
            if (_Life != null)
            {
                _Life.GetDamage(damage);
            }

            GetComponent<SpriteRenderer>().enabled = false;
            gameObject.transform.GetChild(0).gameObject.SetActive(true);

            animator.SetTrigger("Explosion");
            Collider2D[] colliders = Physics2D.OverlapCircleAll(transform.position, radioExplosion);

            foreach (Collider2D hitCollider in colliders)
            {
                Rigidbody2D rb = hitCollider.GetComponent<Rigidbody2D>();

                if (rb != null)
                {
                    // Aplica una fuerza hacia afuera en direcci�n opuesta al centro de la explosi�n
                    Vector2 direction = rb.transform.position - transform.position;
                    rb.AddForce(direction.normalized * fuerzaExplosion, ForceMode2D.Impulse);
                }
            }


            Destroy(gameObject, 0.5f);
        }
    }
}


