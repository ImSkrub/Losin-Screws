using System.Collections;
using System.Collections.Generic;
using UnityEngine;



public class MovimientoMina : MonoBehaviour
{
    [SerializeField] private float velocidad = 1f; // Velocidad del movimiento
    [SerializeField] private float distancia = 0.1f; // Distancia total del movimiento

    private bool haciaDerecha = true;

    void Update()
    {
        if (haciaDerecha)
        {
            transform.Translate(Vector3.right * velocidad * Time.deltaTime);



            if (transform.position.x >= distancia)
            {
                haciaDerecha = false;
            }
        }
        else
        {
            transform.Translate(Vector3.left * velocidad * Time.deltaTime);



            if (transform.position.x <= -distancia)
            {
                haciaDerecha = true;
            }
        }
    }
}