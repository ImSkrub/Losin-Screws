using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PowerUp : MonoBehaviour
{
    [SerializeField] private float increasedJumpForce = 10f;  // Fuerza de salto aumentada
    [SerializeField] private float increasedSpeed = 5f;      // Velocidad aumentada
    [SerializeField] private float powerUpDuration = 3f;     // Duraci�n del power-up en segundos

    private bool isPowerUpActive = false;

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player") && !isPowerUpActive)
        {
            isPowerUpActive = true;
            AplicarPowerUp(other.GetComponent<player>());
            Invoke("DesactivarPowerUp", powerUpDuration);
            Destroy(gameObject);
        }
    }

    void AplicarPowerUp(player _player)
    {
        _player.AplicarPowerUp(increasedJumpForce, increasedSpeed);
    }

    void DesactivarPowerUp()
    {
        isPowerUpActive = false;
    }
}
