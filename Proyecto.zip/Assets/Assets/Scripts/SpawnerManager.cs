using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnerManager : MonoBehaviour
{
    public static SpawnerManager instance;

    public List<Spawner> spawners = new List<Spawner>();

    public GameObject itemPrefab1;

    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
        }
        else
        {
            Destroy(gameObject);
            return;
        }

        GenerarSpawner(); 
    }

    private void GenerarSpawner()
    {
        foreach (var spawner in spawners)
        {
           Instantiate(itemPrefab1, spawner.spawnPoint.position, spawner.spawnPoint.rotation);
        }
    }

    [System.Serializable]
    public class Spawner
    {
        public Transform spawnPoint;
    }
}
