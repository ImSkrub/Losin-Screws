using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class ButtonManager : MonoBehaviour
{
    public void GoToMenu()
    {
        SceneManager.LoadScene(0);
    }
    public void RestartGame()
    {
        SceneManager.LoadScene(1);
    }
    public void ButtonPlay()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
    }
    public void ExitGame()
    {
        Application.Quit();
    }
    public void Config()
    {
        SceneManager.LoadScene(10);
    }
    //public void Levels()
    //{
    //    SceneManager.LoadScene(11);
    //}
    //public void Nivel2()
    //{
    //    SceneManager.LoadScene(2);
    //}
    //public void Nivel3()
    //{
    //    SceneManager.LoadScene(3);
    //}
    //public void Nivel4()
    //{
    //    SceneManager.LoadScene(4);
    //}
    //public void Nivel5()
    //{
    //    SceneManager.LoadScene(5);
    //}
    //public void Nivel6()
    //{
    //    SceneManager.LoadScene(6);
    //}
    //public void Nivel7()
    //{
    //    SceneManager.LoadScene(7);
    //}
}
