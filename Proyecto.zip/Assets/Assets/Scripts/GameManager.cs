using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class GameManager : MonoBehaviour
{
    //Instacimos para llamarlo en donde sea necesario
    public static GameManager Instance;

    //Character
    [SerializeField] GameObject player;

    //Monedas
    public int coin;
    public Text Coins;

    //Power Up
    public int powerUp;
    public Text PowerUpCount;

    private void Awake()
    {
        if (Instance == null)
            Instance = this;
        else
            Destroy(this);
        //Pasar escena si el player muere
        player.GetComponent<Life>().OnDeath += FinishGame;
    }

    //ESC te hace ir al Menu.
    private void Update()
    {
        Coins.text = "" + coin;
        PowerUpCount.text = "" + powerUp;

        if (Input.GetKeyDown(KeyCode.Escape))
        {
            SceneManager.LoadScene(0);
        }
    }

    //Escena de Derrota
    void FinishGame()
    {
        SceneManager.LoadScene(5);
    }
}
